#商城 - html文件 - 全flex布局

#由于没有采用webpack工程，需要手动autofix

采用webstorm scss自动实时编译


